# adaptation pour iota2 des images S2 passées à 5M via superresolution

#!/bin/bash

module load otb



# --- INPUT --- 
cd /work/scratch/data/menezt/DATA/SENTINEL2

DIR_5M="S2_L2A_T47QRB_5m"    # S2 sirs...
DIR_10M="S2_L2A_T47QRB_10m"  # mask
OUT="../input_iota2/5m" # output
TILE="T47QRB"



# ---



mkdir -p "${OUT}/${TILE}"

echo "=== Indexation des dossiers 10m ==="

declare -A REF_BY_DATE

for d in ${DIR_10M}/SENTINEL2A*; do
  base=$(basename "$d")
  date=$(echo "$base" | sed -n 's/.*SENTINEL2A_\([0-9]\{8\}\)-.*/\1/p')
  REF_BY_DATE["$date"]="$base"
done

echo "=== Traitement des images 5m ==="

for stack5m in ${DIR_5M}/SENTINEL2A_*_5m_sisr.tif; do

  file=$(basename "$stack5m")
  date=$(echo "$file" | sed -n 's/.*SENTINEL2A_\([0-9]\{8\}\)_L2A.*/\1/p')

  ref="${REF_BY_DATE[$date]}"

  if [ -z "$ref" ]; then
    echo "⚠️  Pas de référence 10m pour $file"
    continue
  fi

  echo "➡️  $date → $ref"

  TARGET="${OUT}/${TILE}/${ref}"
  MASKS_OUT="${TARGET}/MASKS"
  MASKS_10M="${DIR_10M}/${ref}/MASKS"

  mkdir -p "$MASKS_OUT"

  # --- FRE_STACK ---
  cp "$stack5m" "${TARGET}/${ref}_FRE_STACK.tif"

  # --- Superimposition des masques 10m vers 5m ---
  echo "   ⤷ Reprojection des masques 10m → 5m"

  files=""
  stack_ref="${TARGET}/${ref}_FRE_STACK.tif"

  for mask_file in ${MASKS_10M}/*R1.tif; do
    layer="${MASKS_OUT}/$(basename "${mask_file%.tif}")"

    otbcli_Superimpose \
      -inr "${stack_ref}" \
      -inm "${mask_file}" \
      -out "${layer}_5m.tif" uint8

    # ⛔ on n'ajoute PAS EDG au BINARY_MASK
    if [[ "$mask_file" == *_EDG_R1.tif ]]; then
      files+="${layer}_5m.tif "
    else
      files+="${layer}_5m.tif "
    fi

  done

  if [ -z "$files" ]; then
    echo "⚠️ Aucun masque pour $ref"
    continue
  fi

  
  # --- BINARY MASK 5m ---
  echo "   ⤷ Génération du BINARY_MASK 5m"

  otbcli_BandMath \
    -il ${files} \
    -out "${MASKS_OUT}/${ref}_BINARY_MASK.tif" uint8 \
    -exp "im1b1+im2b1+im3b1==0?0:1"

  # Nettoyage intermédiaire
  for f in ${MASKS_OUT}/*_5m.tif; do
    [[ "$f" == *"_EDG_"* ]] && continue
    rm -f "$f"
  done
  # Renommer les EDG pour retirer le _5m
  for f in "${MASKS_OUT}"/*_EDG_*_5m.tif; do
    mv "$f" "${f/_5m/}"
  done



  echo "✅ $ref terminé" 
done 
module unload otb 
echo "🎉 Pipeline terminé"
