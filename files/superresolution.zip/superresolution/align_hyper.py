import rasterio
from rasterio.warp import reproject, Resampling
from pathlib import Path





# --- INPUT --- #

# Raster de référence
ref_file = "/work/scratch/data/menezt/DATA/input_iota2/5m/T47QRB/SENTINEL2B_20210101-035250-849_L2A_T47QRB_C_V2-2/SENTINEL2B_20210101-035250-849_L2A_T47QRB_C_V2-2_FRE_STACK.tif"

# Répertoire contenant les rasters Hyper
input_dir = Path("/work/scratch/data/menezt/DATA/input_iota2/features/T47QRB/")

output_dir = Path("/work/scratch/data/menezt/DATA/input_iota2/features_5m/T47QRB/")








# Liste de tous les rasters commençant par 'Hyper'
hyper_rasters = list(input_dir.glob("Hyper*.tif"))

print("Rasters à aligner :", hyper_rasters)

# Ouvrir le raster de référence
with rasterio.open(ref_file) as ref:
    ref_crs = ref.crs
    ref_transform = ref.transform
    ref_width = ref.width
    ref_height = ref.height

# Boucle pour aligner tous les Hyper rasters
for src_file in hyper_rasters:
    dst_file = output_dir / (src_file)
    
    with rasterio.open(src_file) as src:
        kwargs = src.meta.copy()
        kwargs.update({
            'crs': ref_crs,
            'transform': ref_transform,
            'width': ref_width,
            'height': ref_height
        })

        with rasterio.open(dst_file, 'w', **kwargs) as dst:
            for i in range(1, src.count + 1):
                reproject(
                    source=rasterio.band(src, i),
                    destination=rasterio.band(dst, i),
                    src_transform=src.transform,
                    src_crs=src.crs,
                    dst_transform=ref_transform,
                    dst_crs=ref_crs,
                    resampling=Resampling.bilinear
                )
    print(f"{src_file} → {dst_file} aligné ✅")

